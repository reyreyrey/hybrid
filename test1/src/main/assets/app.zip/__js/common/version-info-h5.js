
 window.VERSION_INFO_H5 = {
     version: "20180111145109-11492",
     buildtime: "2018-01-11 16:13:44"
 }
 